import 'package:assesment1/widgets/Mytextfield.dart';
import 'package:assesment1/widgets/mycheckboxwidget.dart';
import 'package:assesment1/widgets/mydropdownmenu.dart';
import 'package:assesment1/widgets/myradiobutton.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  String newsletter = "No";
  bool visible = false;
  TextEditingController namecontroller = TextEditingController();
  TextEditingController emailcontroller = TextEditingController();
  List<String> list = [
    "Email",
    "Phone",
    "SMS",
  ];
  String? Genre;
  String x = "";
  bool check = false;
  String PreferredContact = "";
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.grey[100],
        appBar: AppBar(
          backgroundColor: Colors.blue[400],
          title: Center(
            child: Text("A Simple Contact Form"),
          ),
        ),
        body: Center(
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              mytextfieldwidget(
                controller: namecontroller,
                name: "Name:",
                hint: "Enter your name",
              ),
              SizedBox(
                height: 20,
              ),
              mytextfieldwidget(
                controller: emailcontroller,
                name: "Email:",
                hint: "Enter your email",
              ),
              SizedBox(
                height: 20,
              ),
              myradiobutton(
                  Selectorfunction: (value) {
                    setState(() {
                      Genre = value ?? "";
                    });
                  },
                  option1: "Male",
                  option2: "Female",
                  option3: "Other"),
              SizedBox(
                height: 20,
              ),
              Mydropdownmenuwidget(
                list: list,
                selector: (values) {
                  setState(() {
                    PreferredContact = values ?? "";
                  });
                },
              ),
              mycheckbox(Checked: (value) {
                setState(() {
                  check = value;
                });
              }),
              Text(
                x,
                style: TextStyle(color: Colors.red, fontSize: 16),
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                      onPressed: () {
                        setState(() {
                          if (namecontroller.text.isEmpty ||
                              Genre == null ||
                              emailcontroller.text.isEmpty) {
                            x = "please fill all the requiered fields";
                          } else {
                            if (emailcontroller.text.contains("@")) {
                              setState(() {
                                if (check) {
                                  newsletter = "Yes";
                                } else {
                                  newsletter = "No";
                                }
                                x = "";
                                visible = true;
                              });
                            } else {
                              x = "please enter a valid email.";
                            }
                          }
                        });
                      },
                      child: Row(
                        children: [
                          Icon(Icons.check),
                          SizedBox(
                            width: 10,
                          ),
                          Text("Submit")
                        ],
                      )),
                  SizedBox(
                    width: 60,
                  ),
                  ElevatedButton(
                      onPressed: () {
                        setState(() {
                          visible = false;
                          x = "";
                          PreferredContact = list[0];
                          namecontroller.text = "";
                          emailcontroller.text = "";
                          Genre = null;
                          check = false;
                        });
                      },
                      child: Row(
                        children: [
                          Icon(Icons.clear),
                          SizedBox(
                            width: 10,
                          ),
                          Text("Clear"),
                        ],
                      )),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              visible
                  ? Container(
                      width: 400,
                      height: 150,
                      decoration: BoxDecoration(
                        border: Border.all(width: 3, color: Colors.blue),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Center(
                        child: Column(
                          children: [
                            SizedBox(
                              height: 5,
                            ),
                            Text(
                              "Submitted Information: ",
                              style: TextStyle(fontSize: 20),
                            ),
                            Text("Name: " + namecontroller.text),
                            Text("Email:" + emailcontroller.text),
                            Text("Gender:" + Genre!),
                            Text("Preferred Contact Form: " + PreferredContact),
                            Text("Subscribed to Newsletter: " + newsletter),
                          ],
                        ),
                      ),
                    )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }
}
