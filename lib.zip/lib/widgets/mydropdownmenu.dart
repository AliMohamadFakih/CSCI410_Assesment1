import 'package:flutter/material.dart';

// ignore: must_be_immutable
class Mydropdownmenuwidget extends StatefulWidget {
  List<String> list;

  final ValueChanged<String?> selector;
  Mydropdownmenuwidget({super.key, required this.selector, required this.list});

  @override
  State<Mydropdownmenuwidget> createState() => _MydropdownmenuwidgetState();
}

class _MydropdownmenuwidgetState extends State<Mydropdownmenuwidget> {
  String? Selectedvalue;
  @override
  void initState() {
    super.initState();
    Selectedvalue = widget.list.isNotEmpty ? widget.list[0] : null;
  }

  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Prefered contact Form",
          style: TextStyle(fontSize: 20),
        ),
        SizedBox(
          height: 10,
        ),
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 2),
            borderRadius: BorderRadius.circular(8.0),
          ),
          padding: EdgeInsets.symmetric(horizontal: 12.0),
          child: SizedBox(
            width: 325,
            child: DropdownButton<String>(
                value: Selectedvalue,
                items:
                    widget.list.map<DropdownMenuItem<String>>((String option) {
                  return DropdownMenuItem<String>(
                    child: Text(option +
                        "                                                             "),
                    value: option,
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    Selectedvalue = value;
                    widget.selector(value);
                  });
                }),
          ),
        ),
      ],
    );
  }
}
