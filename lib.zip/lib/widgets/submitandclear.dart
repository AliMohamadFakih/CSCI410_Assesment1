import 'package:assesment1/widgets/mybuttons1.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class mytwobuttons extends StatefulWidget {
  final Function() onpressed1;
  final Function() onpressed2;
  String name1;
  String name2;

  mytwobuttons(
      {super.key,
      required this.onpressed1,
      required this.onpressed2,
      required this.name1,
      required this.name2});

  @override
  State<mytwobuttons> createState() => _mytwobuttonsState();
}

class _mytwobuttonsState extends State<mytwobuttons> {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        mybutton(
          onpressed: widget.onpressed1,
          name: widget.name1,
          icons: Icons.check,
        ),
        SizedBox(
          width: 20,
        ),
        mybutton(
          onpressed: widget.onpressed2,
          name: widget.name2,
          icons: Icons.clear,
        )
      ],
    );
  }
}
