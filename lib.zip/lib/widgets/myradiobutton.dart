import 'package:flutter/material.dart';

// ignore: must_be_immutable
class myradiobutton extends StatefulWidget {
  final String option1;
  final String option2;
  final String option3;
  final ValueChanged<String?> Selectorfunction;
  myradiobutton(
      {super.key,
      required this.Selectorfunction,
      required this.option1,
      required this.option2,
      required this.option3});

  @override
  State<myradiobutton> createState() => _myradiobuttonState();
}

class _myradiobuttonState extends State<myradiobutton> {
  String? selected;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Gender",
          style: TextStyle(fontSize: 20),
        ),
        SizedBox(
          width: 350,
          child: Row(
            children: <Widget>[
              Row(
                children: [
                  Radio(
                      value: widget.option1,
                      groupValue: selected,
                      onChanged: (value) {
                        setState(() {
                          selected = value!;
                          widget.Selectorfunction(value);
                        });
                      }),
                  Text(
                    widget.option1,
                    style: TextStyle(fontSize: 20),
                  )
                ],
              ),
              Row(
                children: [
                  Radio(
                      value: widget.option2,
                      groupValue: selected,
                      onChanged: (value) {
                        setState(() {
                          selected = value!;
                          widget.Selectorfunction(value);
                        });
                      }),
                  Text(
                    widget.option2,
                    style: TextStyle(fontSize: 20),
                  )
                ],
              ),
              Row(
                children: [
                  Radio(
                      value: widget.option3,
                      groupValue: selected,
                      onChanged: (value) {
                        setState(() {
                          selected = value!;
                          widget.Selectorfunction(value);
                        });
                      }),
                      
                  Text(
                    widget.option3,
                    style: TextStyle(fontSize: 20),
                  ),
                ],
              )
            ],
          ),
        ),
      ],
    );
  }
}
