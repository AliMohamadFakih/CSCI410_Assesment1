import 'package:flutter/material.dart';

// ignore: must_be_immutable
class mycheckbox extends StatefulWidget {
  final ValueChanged<bool> Checked;
  mycheckbox({super.key, required this.Checked});

  @override
  State<mycheckbox> createState() => _mycheckboxState();
}

class _mycheckboxState extends State<mycheckbox> {
  bool checked = false;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 20,
        ),
        SizedBox(
          width: 40,
          child: Checkbox(
              value: checked,
              onChanged: (bool? value) {
                setState(() {
                  checked = value ?? false;
                  widget.Checked(checked);
                });
              }),
        ),
        Text(
          "Subscribe to news Letter",
          style: TextStyle(fontSize: 15),
        )
      ],
    );
  }
}
