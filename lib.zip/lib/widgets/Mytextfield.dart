import 'package:flutter/material.dart';

// ignore: must_be_immutable
class mytextfieldwidget extends StatefulWidget {
  final String hint;
  final String name;
  TextEditingController controller;
  mytextfieldwidget(
      {super.key,
      required this.hint,
      required this.name,
      required this.controller});

  @override
  State<mytextfieldwidget> createState() => _mytextfieldwidgetState();
}

class _mytextfieldwidgetState extends State<mytextfieldwidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          this.widget.name,
          style: TextStyle(
            fontSize: 20,
          ),
        ),
        SizedBox(
          width: 350,
          child: TextField(
            controller: widget.controller,
            decoration: InputDecoration(
              hintText: this.widget.hint,
              border: OutlineInputBorder(),
            ),
          ),
        )
      ],
    );
  }
}
