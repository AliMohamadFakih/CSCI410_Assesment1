import 'package:flutter/material.dart';

// ignore: must_be_immutable
class mybutton extends StatefulWidget {
  final Function() onpressed;
  final IconData icons;
  String name;
  mybutton(
      {super.key,
      required this.onpressed,
      required this.name,
      required this.icons});

  @override
  State<mybutton> createState() => _mybuttonState();
}

class _mybuttonState extends State<mybutton> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onpressed,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.5), offset: Offset(0, 1)),
          ],
        ),
        child: Row(
          children: [
            Icon(
              widget.icons,
              color: Colors.purple,
              size: 24,
            ),
            SizedBox(width: 8),
            Text(
              widget.name,
              style: TextStyle(
                color: Colors.purple[400],
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
